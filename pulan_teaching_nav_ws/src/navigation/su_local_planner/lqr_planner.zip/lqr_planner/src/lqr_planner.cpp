/***********************************************************
 *
 * @file: lqr_planner.cpp
 * @breif: Contains the linear quadratic regulator (LQR) local planner class
 * @author: Yang Haodong
 * @update: 2024-1-12
 * @version: 1.0
 *
 * Copyright (c) 2024 Yang Haodong
 * All rights reserved.
 * --------------------------------------------------------
 *
 **********************************************************/


#include "lqr_planner.h"


namespace lqr_planner
{
/**
 * @brief Construct a new RPP planner object
 */
LQRPlanner::LQRPlanner() :tf_listener_ (tf_buffer_)
{
  initialized_ = false;
  if (!initialized_) {
    initialized_ = true;
    ros::NodeHandle nh;
    // base
    nh.param("goal_dist_tolerance", goal_dist_tol_, 0.2);
    nh.param("rotate_tolerance", rotate_tol_, 0.5);
    nh.param("convert_offset", convert_offset_, 0.0);
    nh.param("base_frame", base_frame_, base_frame_);
    nh.param("map_frame", map_frame_, map_frame_);

    // lookahead
    nh.param("lookahead_time", lookahead_time_, 1.5);
    nh.param("min_lookahead_dist", min_lookahead_dist_, 0.3);
    nh.param("max_lookahead_dist", max_lookahead_dist_, 0.9);

    // linear velocity
    nh.param("max_v", max_v_, 0.5);
    nh.param("min_v", min_v_, 0.0);
    nh.param("max_v_inc", max_v_inc_, 0.5);

    // angular velocity
    nh.param("max_w", max_w_, 1.57);
    nh.param("min_w", min_w_, 0.0);
    nh.param("max_w_inc", max_w_inc_, 1.57);

    // iteration for ricatti solution
    nh.param("max_iter_", max_iter_, 100);
    nh.param("eps_iter_", eps_iter_, 1e-4);

    // weight matrix for penalizing state error while tracking [x,y,theta]
    std::vector<double> diag_vec;
    nh.getParam("Q_matrix_diag", diag_vec);
    for (size_t i = 0; i < diag_vec.size(); i++)
      Q_(i, i) = diag_vec[i];

    // weight matrix for penalizing input error while tracking[v, w]
    nh.getParam("R_matrix_diag", diag_vec);
    for (size_t i = 0; i < diag_vec.size(); i++)
      R_(i, i) = diag_vec[i];

    double controller_freqency;
    nh.param("/move_base/controller_frequency", controller_freqency, 10.0);
    d_t_ = 1 / controller_freqency;
    
      // Controller parameter
    nh.param("cmd_vel_mode", cmd_vel_mode,
             true);  // whether or not publishing this->cmd_vel
    //目标范围半径
    nh.param("goal_radius", goal_radius_, 1.0);

    //轮距
    nh.param("wheelbase",wheelbase_, 1.1);

        //前瞻点
    nh.param("math_path_proportion",
             math_path_proportion_,5.0);

    odom_sub = nh.subscribe("/lqr/odom", 1, &LQRPlanner::odomCB, this);

    path_sub = nh.subscribe("/lqr/global_plan", 1, &LQRPlanner::pathCB, this);
    goal_sub =
        nh.subscribe("/lqr/goal", 1, &LQRPlanner::goalCB, this);
    amcl_sub = nh.subscribe("/localization_pose", 5, &LQRPlanner::amclCB, this);
    current_vel_sub =
        nh.subscribe("/cmd_vel", 1, &LQRPlanner::robotVelCB, this);

    marker_pub =
        nh.advertise<visualization_msgs::Marker>("/lqr/path_marker", 10);
    ackermann_pub = nh.advertise<ackermann_msgs::AckermannDrive>(
        "/lqr/ackermann_cmd", 1, true);
    if (cmd_vel_mode)
      cmdvel_pub =
          nh.advertise<geometry_msgs::Twist>("/lqr/round_cmd_vel", 1, true);

    target_pt_pub_ = nh.advertise<geometry_msgs::PointStamped>("/target_point", 10);
    current_pose_pub_ = nh.advertise<geometry_msgs::PoseStamped>("/current_pose", 10);

        // Timer
    timer1 = nh.createTimer(ros::Duration((1.0) / controller_freqency),
                            &LQRPlanner::controlLoopCB,
                            this);  // Duration(0.05) -> 20Hz

    // Init variables
    goal_received_ = false;
    goal_reached_ = false;
    // Visualization Marker Settings
    initMarker();
    cmd_vel = geometry_msgs::Twist();
    ackermann_cmd = ackermann_msgs::AckermannDrive();

    ROS_INFO("LQR planner initialized!");
  } else
    ROS_WARN("LQR planner has already been initialized.");
}

/**
 * @brief Destroy the RPP planner object
 */
LQRPlanner::~LQRPlanner()
{
}

void LQRPlanner::initMarker() {
  points.header.frame_id = line_strip.header.frame_id =
      goal_circle.header.frame_id = "odom";
  points.ns = line_strip.ns = goal_circle.ns = "Markers";
  points.action = line_strip.action = goal_circle.action =
      visualization_msgs::Marker::ADD;
  points.pose.orientation.w = line_strip.pose.orientation.w =
      goal_circle.pose.orientation.w = 1.0;
  points.id = 0;
  line_strip.id = 1;
  goal_circle.id = 2;

  points.type = visualization_msgs::Marker::POINTS;
  line_strip.type = visualization_msgs::Marker::LINE_STRIP;
  goal_circle.type = visualization_msgs::Marker::CYLINDER;
  // POINTS markers use x and y scale for width/height respectively
  points.scale.x = 0.2;
  points.scale.y = 0.2;

  // LINE_STRIP markers use only the x component of scale, for the line width
  line_strip.scale.x = 0.1;

  goal_circle.scale.x = goal_radius_;
  goal_circle.scale.y = goal_radius_;
  goal_circle.scale.z = 0.1;

  // Points are green
  points.color.g = 1.0f;
  points.color.a = 1.0;

  // Line strip is blue
  line_strip.color.b = 1.0;
  line_strip.color.a = 1.0;

  // goal_circle is yellow
  goal_circle.color.r = 1.0;
  goal_circle.color.g = 1.0;
  goal_circle.color.b = 0.0;
  goal_circle.color.a = 0.5;
}

void LQRPlanner::robotVelCB(const geometry_msgs::Twist::ConstPtr& msg) {
  //    this->Vcmd = msg->linear.x;
  this->cmd_z = msg->angular.z;
}

void LQRPlanner::odomCB(const nav_msgs::Odometry::ConstPtr& odomMsg) {
  // ROS_INFO("enter odomCB!");
  this->odom = *odomMsg;
}

void LQRPlanner::pathCB(const nav_msgs::Path::ConstPtr& pathMsg) {
  //规划全局路径后，这个消息要重新定位才能拿到
  // ROS_INFO("---------enter pathCB-----------");
  //这个的信息也是odom坐标系上的
  // std::string frame_id = pathMsg->header.frame_id;
  // ROS_INFO("Received Path message in frame: %s", frame_id.c_str());
  this->map_path = *pathMsg;
  setPlan(map_path.poses);
}
/**
 * @brief  Set the plan that the controller is following
 * @param orig_global_plan the plan to pass to the controller
 * @return  true if the plan was updated successfully, else false
 */
bool LQRPlanner::setPlan(const std::vector<geometry_msgs::PoseStamped>& orig_global_plan)
{
  if (!initialized_)
  {
    ROS_ERROR("This planner has not been initialized, please call initialize() before using this planner");
    return false;
  }

  //ROS_INFO("Got new plan");

  // set new plan
  global_plan_.clear();
  global_plan_ = orig_global_plan;

  // reset plan parameters
  if (goal_x_ != global_plan_.back().pose.position.x || goal_y_ != global_plan_.back().pose.position.y)
  {
    goal_x_ = global_plan_.back().pose.position.x;
    goal_y_ = global_plan_.back().pose.position.y;
    goal_rpy_ = getEulerAngles(global_plan_.back());
    goal_reached_ = false;
  }

  return true;
}

/*
 * @brief 获取目标点信息
 */
void LQRPlanner::goalCB(const geometry_msgs::PoseStamped::ConstPtr& goalMsg) {
  // ROS_INFO("-----------enter goalCB--------------");
  this->map_path.poses.clear();
  this->goal_pos = goalMsg->pose.position;
  goal_received_ = true;
  goal_reached_ = false;
  // try {
  //   geometry_msgs::PoseStamped odom_goal;
  //   if (!tf_buffer_.canTransform(odom_frame_, goalMsg->header.frame_id,
  //                                ros::Time(0), ros::Duration(0.1))) {
  //     ROS_WARN("1.Failed to find a transform from %s to %s",
  //              odom_frame_.c_str(), goalMsg->header.frame_id.c_str());
  //   }
  //   tf_buffer_.transform(*goalMsg, odom_goal, odom_frame_);
  //   odom_goal_pos = odom_goal.pose.position;
  //   goal_received_ = true;
  //   goal_reached_ = false;

  //   /*Draw Goal on RVIZ*/
  //   goal_circle.pose = odom_goal.pose;
  //   marker_pub.publish(goal_circle);
  // } catch (tf2::TransformException& ex) {
  //   ROS_ERROR("3333 %s", ex.what());
  //   // 处理转换异常的代码
  // }
}

/**
 * @brief 得到amcl定位信息，map坐标系上的
 */
void LQRPlanner::amclCB(
    const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& amclMsg) {
  // ROS_INFO("--------enter amclCB-------------");

  if (this->goal_received_) {
    double car2goal_x = this->goal_pos.x - amclMsg->pose.pose.position.x;
    double car2goal_y = this->goal_pos.y - amclMsg->pose.pose.position.y;
    double dist2goal = sqrt(car2goal_x * car2goal_x + car2goal_y * car2goal_y);
    if (dist2goal < this->goal_radius_) {
      this->goal_reached_ = true;
      this->goal_received_ = false;
      ROS_INFO("Goal Reached !");
    }
  }
}

/**
 * @brief 定时计算速度
 */
void LQRPlanner::controlLoopCB(const ros::TimerEvent&) {
  //ROS_INFO("enter controlLoopCB!");
  computeVelocityCommands();
  //发布控制指标
  //publish_controlindicators();
}

/**
 * @brief Given the current position, orientation, and velocity of the robot, compute the velocity commands
 * @param cmd_vel will be filled with the velocity command to be passed to the robot base
 * @return  true if a valid trajectory was found, else false
 */
bool LQRPlanner::computeVelocityCommands()
{
  if (!initialized_)
  {
    ROS_ERROR("RPP planner has not been initialized");
    return false;
  }
  
    if (global_plan_.empty()) {
    // ROS_ERROR("global_plan_ is empty");
    return false;
  }
  // odometry observation - getting robot velocities in robot frame
  // nav_msgs::Odometry base_odom;
  // odom_helper_->getOdom(base_odom);
  // current_ps_ 要得到map坐标系上机器人的位置信息
  // current angle
  geometry_msgs::Pose carPose = this->odom.pose.pose;
  geometry_msgs::Twist carVel = this->odom.twist.twist;
  // odometry observation - getting robot velocities in robot frame
  // 还是odom坐标系上的信息，但是好像下面只是用到了base_odom的twist信息
  nav_msgs::Odometry 
  base_odom = this->odom;
  
  // get robot position in global frame
  geometry_msgs::PoseStamped robot_pose_odom,robot_pose_map;
  robot_pose_odom.pose = this->odom.pose.pose;
  robot_pose_odom.header.stamp = this->odom.header.stamp;
  robot_pose_odom.header.frame_id = this->odom.header.frame_id;

   try {
    geometry_msgs::PoseStamped odom_goal;
    if (!tf_buffer_.canTransform("map", "odom",
                                 ros::Time(0), ros::Duration(0.1))) {
      ROS_WARN("1.Failed to find a transform from odom to map");
    }
    tf_buffer_.transform(robot_pose_odom, robot_pose_map, "map");
  } catch (tf2::TransformException& ex) {
    ROS_ERROR("1111 %s", ex.what());
    // 处理转换异常的代码
  }
  // transform global plan to robot frame
  std::vector<geometry_msgs::PoseStamped> prune_plan = _prune(robot_pose_map);
  
  // calculate look-ahead distance
  double vt = std::hypot(base_odom.twist.twist.linear.x, base_odom.twist.twist.linear.y);
  double wt = base_odom.twist.twist.angular.z;
  double L = _getLookAheadDistance(vt);
  ROS_INFO("-----------5-----------");
  // get the particular point on the path at the lookahead distance
  //geometry_msgs::PointStamped lookahead_pt = _getLookAheadPoint(L, robot_pose_map, prune_plan);
  ROS_INFO("-----------6-----------");
  // calculate commands
   if (this->goal_received_&&!this->goal_reached_){
    // double theta_r = atan2(lookahead_pt.point.y - robot_pose_map.pose.position.y,
    //                        lookahead_pt.point.x - robot_pose_map.pose.position.x);
    geometry_msgs::Point odom_car2WayPtVec = get_odom_car2WayPtVec(carPose);
    double theta_r = getYawFromPose(carPose);
    //double e_theta = tf2::getYaw(robot_pose_map.pose.orientation) - theta_r;
    double e_theta = getEta(carPose);
    regularizeAngle(e_theta);
    ROS_INFO(
        "odom_car2WayPtVec.x=%f,odom_car2WayPtVec.y=%f,theta_r=%f,e_theta=%f",
        odom_car2WayPtVec.x, odom_car2WayPtVec.y, theta_r, e_theta);
    // state vector (p - p_ref)
    Eigen::Vector3d x(odom_car2WayPtVec.x,odom_car2WayPtVec.y, e_theta);
    std::vector<double> ref = { vt, theta_r };
    // ROS_INFO("robot_pose_map.pose.position.x=%f,lookahead_pt.point.x=%f,robot_pose_map.pose.position.y=%f,lookahead_pt.point.y=%f,e_theta=%f",
    // robot_pose_map.pose.position.x,lookahead_pt.point.x,robot_pose_map.pose.position.y,lookahead_pt.point.y,e_theta);
    // ROS_INFO("vt=%f,theta_r=%f", vt, theta_r);
     
    // control vector
    Eigen::Vector2d u = _lqrControl(x, ref);
    ROS_INFO("u[0]=%f,u[1]=%f", u[0], u[1]);
    // this->cmd_vel.linear.x = linearRegularization(base_odom, u[0]);
    // this->cmd_vel.angular.z = angularRegularization(base_odom, u[1]);
  }
    else if (!this->goal_received_) {
      ROS_INFO("GOAL Fail to receive");
      this->cmd_vel.linear.x = 0.0;
      this->cmd_vel.angular.z = 0.0;
    }
    else if (this->goal_reached_) {
      ROS_INFO("GOAL REACHED");
      this->cmd_vel.linear.x = 0.0;
      this->cmd_vel.angular.z = 0.0;
    }

  // publish cmd_vel发布速度
  this->ackermann_cmd.steering_angle = atan(this->cmd_vel.angular.z*wheelbase_)/this->cmd_vel.linear.x;
  this->ackermann_cmd.speed = this->cmd_vel.linear.x;
  this->ackermann_pub.publish(this->ackermann_cmd);

  if (this->cmd_vel_mode) {
    this->cmdvel_pub.publish(this->cmd_vel);
  }

  // publish lookahead pose
 //target_pt_pub_.publish(lookahead_pt);

  // publish robot pose
  current_pose_pub_.publish(robot_pose_map);

  return true;
}

/**
 * @brief calculate the look-ahead distance with current speed dynamically
 * @param vt  the current speed
 * @return L  the look-ahead distance
 */
double LQRPlanner::_getLookAheadDistance(double vt)
{
  double lookahead_dist = fabs(vt) * lookahead_time_;
  return clamp(lookahead_dist, min_lookahead_dist_, max_lookahead_dist_);
}

/**
 * @brief find the point on the path that is exactly the lookahead distance away from the robot
 * @param lookahead_dist    the lookahead distance
 * @param robot_pose_global the robot's pose  [global]
 * @param prune_plan        the pruned plan
 * @return point            the lookahead point map坐标系
 */
geometry_msgs::PointStamped LQRPlanner::_getLookAheadPoint(double lookahead_dist,
                                                           geometry_msgs::PoseStamped robot_pose_global,
                                                           const std::vector<geometry_msgs::PoseStamped>& prune_plan)
{
  geometry_msgs::PointStamped pt;

  double rx = robot_pose_global.pose.position.x;
  double ry = robot_pose_global.pose.position.y;
  ROS_INFO("-----------1-----------");
  // Find the first pose which is at a distance greater than the lookahead
  // distance
  auto goal_pose_it =
      std::find_if(prune_plan.begin(), prune_plan.end(),
                   [&](const geometry_msgs::PoseStamped& ps) {
                     return dist(ps, robot_pose_global) >= lookahead_dist;
                   });
  ROS_INFO("-----------2-----------");
  // If the no pose is not far enough, take the last pose
  if (goal_pose_it == prune_plan.end())
  {
    goal_pose_it = std::prev(prune_plan.end());
    pt.point.x = goal_pose_it->pose.position.x;
    pt.point.y = goal_pose_it->pose.position.y;
      ROS_INFO("-----------3-----------");
  }

  else
  {
    // find the point on the line segment between the two poses
    // that is exactly the lookahead distance away from the robot pose (the origin)
    // This can be found with a closed form for the intersection of a segment and a circle
    // Because of the way we did the std::find_if, prev_pose is guaranteed to be inside the circle,
    // and goal_pose is guaranteed to be outside the circle.
    //使用 C++ 标准库中的 std::prev 函数来获取给定迭代器 goal_pose_it 的前一个位置的迭代器
    auto prev_pose_it = std::prev(goal_pose_it);

    double px = prev_pose_it->pose.position.x;
    double py = prev_pose_it->pose.position.y;
    double gx = goal_pose_it->pose.position.x;
    double gy = goal_pose_it->pose.position.y;
    
    // transform to the robot frame so that the circle centers at (0,0)
    std::pair<double, double> prev_p(px - rx, py - ry);
    std::pair<double, double> goal_p(gx - rx, gy - ry);
    std::vector<std::pair<double, double>> i_points = circleSegmentIntersection(prev_p, goal_p, lookahead_dist);
    ROS_INFO("-----------4-----------");
    //问题出在这里
    // ROS_INFO("i_points[0].first=%f,i_points[0].second=%f,rx=%f,ry=%f",
    //          i_points[0].first, i_points[0].second, rx, ry);
        ROS_INFO("rx=%f,ry=%f", rx, ry);
        ROS_INFO("px=%f,py=%f", px, py);
        ROS_INFO("gx=%f,gy=%f", gx, gy);
    //  pt.point.x = i_points[0].first + rx;
    //  pt.point.y = i_points[0].second + ry;
     pt.point.x = px;
     pt.point.y = py;
  }
  ROS_INFO("-----------7-----------");
  pt.header.frame_id = goal_pose_it->header.frame_id;
  pt.header.stamp = goal_pose_it->header.stamp;
  ROS_INFO("-----------8-----------");
  return pt;
}

/**
 * @brief 返回前瞻点在车辆坐标系上的位置
 * @param carPose odom回调函数得到的位置信息
 * @return 返回前瞻点在车辆坐标系上的坐标
 */
double LQRPlanner::getYawFromPose(const geometry_msgs::Pose& carPose) {
  float x = carPose.orientation.x;
  float y = carPose.orientation.y;
  float z = carPose.orientation.z;
  float w = carPose.orientation.w;
  double tmp, yaw;
  tf2::Quaternion q(x, y, z, w);
  tf2::Matrix3x3 quaternion(q);
  quaternion.getRPY(tmp, tmp, yaw);
  while (yaw >= M_PI) {
    yaw -= 2 * M_PI;
  }
  while (yaw <= -M_PI) {
    yaw += 2 * M_PI;
  }

  return yaw;
}

  /**
 * @brief 返回前瞻点在车辆坐标系上的位置
 * @param carPose odom回调函数得到的位置信息
 * @return 返回前瞻点在车辆坐标系上的坐标
 */
geometry_msgs::Point LQRPlanner::get_odom_car2WayPtVec(
    const geometry_msgs::Pose & carPose) {
  geometry_msgs::Point carPose_pos = carPose.position;
  double carPose_yaw = getYawFromPose(carPose);
  ROS_INFO("carPose_yaw=%f", carPose_yaw);
  geometry_msgs::Point forwardPt;
  geometry_msgs::Point odom_car2WayPtVec;
  foundForwardPt_ = false;

  if (goal_reached_) {
    forwardPt = odom_goal_pos;
    foundForwardPt_ = false;
    ROS_INFO("goal REACHED!");
  } else if (!goal_reached_ && map_path.poses.size() > 1) {
    ROS_INFO("---------------enter----------");
    map_path_pose_ =
        map_path.poses[map_path.poses.size() / math_path_proportion_];
    geometry_msgs::PoseStamped odom_path_pose;

    try {
      if (!tf_buffer_.canTransform(odom_frame_, map_frame_, ros::Time(0),
                                   ros::Duration(0.1))) {
        ROS_WARN("5.Failed to find a transform from %s to %s",
                 map_frame_.c_str(), odom_frame_.c_str());
      }
      tf_buffer_.transform(map_path_pose_, odom_path_pose, odom_frame_);
      forwardPt = odom_path_pose.pose.position;

    } catch (tf2::TransformException& ex) {
      ROS_ERROR("5555 %s ", ex.what());
      // 处理转换异常的代码
    }
    foundForwardPt_ = true;
  }

  //获得前瞻点在车辆坐标系上的坐标
  odom_car2WayPtVec.x = cos(carPose_yaw) * (forwardPt.x - carPose_pos.x) +
                        sin(carPose_yaw) * (forwardPt.y - carPose_pos.y);
  odom_car2WayPtVec.y = -sin(carPose_yaw) * (forwardPt.x - carPose_pos.x) +
                        cos(carPose_yaw) * (forwardPt.y - carPose_pos.y);
  return odom_car2WayPtVec;
}

/**
 * @brief 获取车辆与前瞻点朝向误差
 * @param carPose odom回调函数得到的位置信息
 * @return 朝向误差
 */
double LQRPlanner::getEta(const geometry_msgs::Pose& carPose) {
  //获取前瞻点
  geometry_msgs::Point odom_car2WayPtVec = get_odom_car2WayPtVec(carPose);
  //返回朝向误差
  return atan2(odom_car2WayPtVec.y, odom_car2WayPtVec.x);
}

/**
 * @brief Prune the path, removing the waypoints that the robot has already passed and distant waypoints
 * 修剪路径，删除机器人已经通过的航点和远处的航点
 * @param robot_pose_global the robot's pose  [global]
 * @return pruned path
 */
std::vector<geometry_msgs::PoseStamped> LQRPlanner::_prune(const geometry_msgs::PoseStamped robot_pose_global)
{
  // Transform the near part of the global plan into the robot's frame of reference.
  std::vector<geometry_msgs::PoseStamped> prune_path;
  for (auto it = global_plan_.begin(); it < global_plan_.end(); it++)
    prune_path.push_back(*it);
  return prune_path;
}

/**
 * @brief Execute LQR control process
 * @param x   state error vector
 * @param ref reference point
 * @return u  control vector
 */
Eigen::Vector2d LQRPlanner::_lqrControl(Eigen::Vector3d x, std::vector<double> ref)
{
  // for diffrential wheel model
  double v_r = ref[0], theta_r = ref[1];

  // state equation
  Eigen::Matrix3d A = Eigen::Matrix3d::Identity();
  A(0, 2) = -v_r * sin(theta_r) * d_t_;
  A(1, 2) = v_r * cos(theta_r) * d_t_;

  Eigen::MatrixXd B = Eigen::MatrixXd::Zero(3, 2);
  B(0, 0) = cos(theta_r) * d_t_;
  B(1, 0) = sin(theta_r) * d_t_;
  B(2, 1) = d_t_;

  // discrete iteration Ricatti equation
  Eigen::Matrix3d P, P_;
  P = Q_;
  for (int i = 0; i < max_iter_; i++)
  {
    Eigen::Matrix2d temp = R_ + B.transpose() * P * B;
    P_ = Q_ + A.transpose() * P * A - A.transpose() * P * B * temp.inverse() * B.transpose() * P * A;
    if ((P - P_).array().abs().maxCoeff() < eps_iter_)
      break;
    P = P_;
  }

  // feedback
  Eigen::MatrixXd K = -(R_ + B.transpose() * P_ * B).inverse() * B.transpose() * P_ * A;
  return K * x;
}


double LQRPlanner::dist(const geometry_msgs::PoseStamped& node1, const geometry_msgs::PoseStamped& node2)
{
  return std::hypot(node1.pose.position.x - node2.pose.position.x, node1.pose.position.y - node2.pose.position.y);
}
/**
 * @brief Formula for intersection of a line with a circle centered at the origin
 * @note  https://mathworld.wolfram.com/Circle-LineIntersection.html
 * @param p1/p2     the two point in the segment
 * @param r         the radius of circle centered at the origin
 * @return points   the intersection points of a line and the circle
 */
std::vector<std::pair<double, double>> LQRPlanner::circleSegmentIntersection(const std::pair<double, double>& p1,
                                                                 const std::pair<double, double>& p2, double r)
{
  std::vector<std::pair<double, double>> i_points;

  double x1 = p1.first;
  double x2 = p2.first;
  double y1 = p1.second;
  double y2 = p2.second;

  double dx = x2 - x1;
  double dy = y2 - y1;
  double dr2 = dx * dx + dy * dy;
  double D = x1 * y2 - x2 * y1;

  // the first element is the point within segment
  double d1 = x1 * x1 + y1 * y1;
  double d2 = x2 * x2 + y2 * y2;
  double dd = d2 - d1;

  double delta = std::sqrt(r * r * dr2 - D * D);
  //dr太小了，说明前瞻点与目标点很接近，因为截取的global_plan_太短
  // ROS_INFO("r=%f,dr2=%f,D=%f",r,dr2,D);
  // ROS_INFO("delta=%f", delta);
  if (delta >= 0) {
    if (delta == 0)
      i_points.emplace_back(D * dy / dr2, -D * dx / dr2);
    else
    {
      i_points.emplace_back((D * dy + std::copysign(1.0, dd) * dx * delta) / dr2,
                            (-D * dx + std::copysign(1.0, dd) * dy * delta) / dr2);
      i_points.emplace_back((D * dy - std::copysign(1.0, dd) * dx * delta) / dr2,
                            (-D * dx - std::copysign(1.0, dd) * dy * delta) / dr2);
    }
  }
  else{
    i_points.emplace_back(p1.first,p1.second) ;
  }
  ROS_INFO("i_points[0].first=%f,i_points[0].second=%f", i_points[0].first,
           i_points[0].second);
  return i_points;
}

}  // namespace lqr_planner



/*****************/
/* MAIN FUNCTION */
/*****************/
int main(int argc, char** argv) {
  // Initiate ROS
  ros::init(argc, argv, "lqr");
  lqr_planner::LQRPlanner controller;
  ros::AsyncSpinner spinner(2);  // Use multi threads
  spinner.start();
  ros::waitForShutdown();
  ROS_INFO("------------3------------!");
  return 0;
}
